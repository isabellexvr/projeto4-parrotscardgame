let numeroDeCartas = parseInt(prompt("Digite aqui o número de cartas (de 4 a 14, números pares)"));

const numerosPossiveis = [4, 6, 8, 10, 12, 14];

function aoCarregar() {
    for (i = 0; i < numerosPossiveis.length; i++) {
        if (numeroDeCartas === numerosPossiveis[i] && numeroDeCartas % 2 === 0) {
            adicionarCartas();
        }
    }
}
aoCarregar()

function adicionarCartas() {
    const divCartas = document.querySelector('.cartas');
    for (i = 0; i < numeroDeCartas; i++) {
        let carta = `<div class="carta" onclick="virar()">
                        <img src="imagens/front 1.png" alt="parrot">
                    </div>`;
        divCartas.innerHTML += carta
    }

}

function virar() {

}